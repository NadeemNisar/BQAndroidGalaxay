package com.example.jsonapp;

import java.util.UUID;

import org.json.JSONException;
import org.json.JSONObject;

public class Activity {
	
	//public UUID Activity_ID;
	private String Activity_ID; 
	
	private String ActivityID;

	private String ActivityCode; 

	private String ActivitySub;
    
	private String ActivityDescription;
	
    private int ActivityBillable;
    
    public Activity()
    {}
    
    public Activity(JSONObject obj)
    {   
	   try 
    	{
			   Activity_ID=obj.getString("Activity_ID");
		       ActivityID=obj.getString("ActivityID");
    	       ActivityCode=obj.getString("ActivityCode");
    	       ActivitySub=obj.getString("ActivitySub");
    	       ActivityDescription=obj.getString("ActivityDescription");
    	       //ActivityBillable=obj.getString(ActivityBillable);
    	} 
    	catch (JSONException e) 
    	{
			e.printStackTrace();
		}
    }
    
    ////Get Methods
    public String GetActivity_ID() { return Activity_ID; }
    
    public String GetActivityID() { return ActivityID; }
    
    public String GetActivityCode() { return ActivityCode; }
    
    public String GetActivitySub() { return ActivitySub; }
    
    public String GetActivityDescription() { return ActivityDescription; }
    
    //public short GetActivityBillable() { return ActivityBillable; }
    //////////////////////
    
    ////Set Methods
    public void SetActivity_ID(String act_ID) { Activity_ID=act_ID; }
    
    public void SetActivityID(String actID) { ActivityID=actID;    }
    
    public void SetActivityCode(String actCode) { ActivityID=actCode;  }
    
    public void SetActivitySub(String actSub) {	ActivitySub=actSub;  }
    
    public void SetActivityDescription(String actDesc) { ActivityDescription=actDesc;}
    
    public void SetActivityBillable(short actBillable) { ActivityBillable=actBillable; }
    //////////////////////
    
}
