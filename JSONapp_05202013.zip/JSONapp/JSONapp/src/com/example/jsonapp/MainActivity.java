package com.example.jsonapp;

import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;


public class MainActivity extends Activity {

	String jsondata="";
	ArrayList<String> Ids;
	ArrayList<String> listValues;
	Context context;
	
	
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
     
        context=this;
        Log.d("Start","Connection...");
        fpGetJSON();    
        Log.d("Async","_End");
        
        
        ///Post Button
        Button btnPost=(Button)findViewById(R.id.btnPost);
        btnPost.setOnClickListener( new OnClickListener(){
			@Override
			public void onClick(View v) {
				Log.d("Post","Pressed");
				fpPostJSON();
			}
		});
        
        
        ///Put Button
        Button btnNew=(Button)findViewById(R.id.btnNew);
        btnNew.setOnClickListener( new OnClickListener(){
			@Override
			public void onClick(View v) {
				Log.d("New","Pressed");
				fpPutJSON();
			}
		});
	}
    
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
	   //Inflate the menu; this adds items to the action bar if it is present.
	        getMenuInflater().inflate(R.menu.main, menu);
	        return true;
	}
	    
    private void fpGetJSON() {
    	new GetJSON().execute();
	}
     
    private void fpPutJSON() {
    	new PutJSON().execute();
	}

    private void fpPostJSON() {
    	new PostJSON().execute();
	}

    class GetJSON extends AsyncTask<Void, Integer, Void>
	{
	     protected void onPreExecute() {
		  // update the UI immediately after the task is executed
		  super.onPreExecute();
		  Log.d("Async","PreExecute");	
		 }
	     
		 @Override
		 protected Void doInBackground(Void... params) {
			Log.d("Async","BackGround");
		    fpJSONRetrieve();
			return null;
		 }
	 
		 @Override
		 protected void onProgressUpdate(Integer... values) {
		  super.onProgressUpdate(values);
		  Log.d("Async","Update");
		 }
	  
		 @Override
		 protected void onPostExecute(Void result) {
		  super.onPostExecute(result);
		  Log.d("Async","Post");
	      fpSetJSONData();
		 }

		 private void fpJSONRetrieve()
			{
				Log.d("JSON","Retrieval");
				clsJSON json=new clsJSON("Activity");
				jsondata=json.GetActvityData();
		        json=null; 
	  		}
	
		 private void fpSetJSONData() {
			 
			    Ids=new ArrayList<String>();
			 	listValues=new ArrayList<String>();
				
			 	try {
	         
			     	     // Getting Array of Activity
			     	     Log.d("Try Catch JSON ","Parse JSON String Now! ");
			     	     JSONArray jsonActivities = new JSONArray(jsondata);
			     	     Log.d("JSON String converted to","JSON Array");
			     	     Log.d("JSON Array Length :",String.valueOf(jsonActivities.length()));
			              
			     	     Ids.clear();
			     	     listValues.clear();
			     	     
			     	     //Activity[] activities = null; // =new Activity[jsonActivities.length()];
			     	     
			     	    
			     	     // looping through All Activities
			     	     for(int i = 0; i < jsonActivities.length(); i++)
			     	        {
			     		 	   
			     	    	   JSONObject jObj = jsonActivities.getJSONObject(i); 
			     		 	   Log.d("JSON Object:" + i,"Retrieved");
			     		 	   
			     		 	   //activities[i]=new Activity(1);
			     		 	 
			     		 	   
			     		 	   Ids.add(jObj.getString("Activity_ID"));
			     		 	   listValues.add(jObj.getString("ActivityID") +  jObj.getString("ActivityDescription"));
			     		 	}
			     	     Log.d("Before","ListView");
			     	     
			     	     // Getting adapter by passing data ArrayList
			     	     ListView list=(ListView)findViewById(R.id.mydataList);
			     	     customListView mylist=new customListView(context,Ids,listValues);
			     	     
			     	     Log.d("Inter","ListView");
			     	     list.setAdapter(mylist);
			     	     mylist.notifyDataSetChanged();
			     	     list.invalidateViews();
			     	     list.setSelector( R.drawable.listselector);
			     	     Log.d("After","ListView");
	     	     
	             } 
	             catch (JSONException e) 
	             {
	                  e.printStackTrace();
	             }
			 	
	    }
	}	

	class PutJSON extends AsyncTask<Void, Integer, Void>
	{
	     protected void onPreExecute() {
		  // update the UI immediately after the task is executed
		  super.onPreExecute();
		  Log.d("PutActvity","PreExecute");	
		 }
	     
		 @Override
		 protected Void doInBackground(Void... params) {
			Log.d("PutActvity","BackGround");
			clsJSON putjson=new clsJSON("Activity");
			putjson.PutActivityData();
	        putjson=null;
		    return null;
		 }
	 
		 @Override
		 protected void onProgressUpdate(Integer... values) {
		  super.onProgressUpdate(values);
		  Log.d("PutActvity","Update");
		 }
	  
		 @Override
		 protected void onPostExecute(Void result) {
		  super.onPostExecute(result);
		  Log.d("PutActvity","Post");
		  fpRefresh();
	     }
    }
	
	class PostJSON extends AsyncTask<Void, Integer, Void>
	{
	     protected void onPreExecute() {
		  // update the UI immediately after the task is executed
		  super.onPreExecute();
		  Log.d("PostActvity","PreExecute");	
		 }
	     
		 @Override
		 protected Void doInBackground(Void... params) {
			Log.d("PostActvity","BackGround");
			clsJSON putjson=new clsJSON("Activity");
			putjson.PostActivityData();
	        putjson=null;
		    return null;
		 }
	 
		 @Override
		 protected void onProgressUpdate(Integer... values) {
		  super.onProgressUpdate(values);
		  Log.d("PostActvity","Update");
		 }
	  
		 @Override
		 protected void onPostExecute(Void result) {
		  super.onPostExecute(result);
		  Log.d("PostActvity","Post");
		  fpRefresh();
	     }
    }

    private void fpRefresh()
    {
    	 //Refresh Screen
	     finish();
		 Intent myIntent = new Intent(context, MainActivity.class);
		 startActivity(myIntent);
    }
}