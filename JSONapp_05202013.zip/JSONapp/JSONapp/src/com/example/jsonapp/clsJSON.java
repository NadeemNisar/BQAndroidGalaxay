package com.example.jsonapp;

import java.io.IOException;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.UUID;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

public class clsJSON {
	
	// Call BQE API  to make request
	private static String url = "";
	private static int i=0;
	
	// activity JSONArray
	JSONArray activities = null;
		
	public clsJSON(String list)
	{ 
		url="http://192.168.13.17/BQEGalaxyApi/api/" + list;
	}
	
	
	//Method to Get activity list from Cloud
	public String GetActvityData()
	{
		String result = null;
		
		//Step 1: Initialize HTTP CLient
		HttpClient  httpClient=new DefaultHttpClient();
    	
    	//Step 2: Ready the HTTP Get Request
    	HttpGet httpGetRequest=new HttpGet();
    	try {
			httpGetRequest.setURI(new URI(url));
			httpGetRequest.setHeader("Accept", "application/json");
			httpGetRequest.setHeader("Host","192.168.13.17");
			httpGetRequest.setHeader("Authorization","Basic U2hhZmF0OlRlc3Q6NzE5QTRFQTUtQkY1OS00QkE3LUFBRDktNDc3N0Y4MkVFNTNFOjYzMTZBNDk2LUYzRUYtNEI5Qy1CQkQxLUI1MDQ1RDk2MTVDQjo=");
	    	Log.d("JSon","Get request");
		} 
    	catch (URISyntaxException e1) {
    		Log.d("JSon","Get request Error");
			e1.printStackTrace();
		}
    	
        //Step 3:Execute the Request and Set Response Object
    	HttpResponse response = null;
    	try {
    		 Log.d("JSon","response start");
			 response = httpClient.execute(httpGetRequest);
			 Log.d("JSon","response");

		} catch (ClientProtocolException e1) {
			Log.d("JSon","response Error in Protocol");
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			Log.d("JSon","response IOException");
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (Exception e){
			Log.d("JSON","General Response Exception : " + e.getMessage());
			e.printStackTrace();
		}

    	//Step 4: Extract data entity from response object
    	HttpEntity entity=response.getEntity();
    	Log.d("JSON","entity");
    	if (entity!=null)
    	{
    		
			try {
				result = EntityUtils.toString(entity);
				//result=_getResponseBody(entity);
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
            Log.d("JSON","Object Retrieved");
          
         }
    	
    	 Log.d("Activity Returned:",result);
		 return result;
	}
	
	//Method to delete an activity in a cloud
	public int DeleteActivityData()
	{
		Log.d("Beware","I am going to delete you.");
		
		//Step 1: Initialize HTTP CLient
		HttpClient  httpClient=new DefaultHttpClient();
    	
    	//Step 2: Ready the HTTP Get Request
    	HttpDelete httpDeleteRequest=new HttpDelete();
    	Log.d("Delete URI",url);
    	try {
    		httpDeleteRequest.setURI(new URI(url));
    		httpDeleteRequest.setHeader("Accept", "application/json");
    		httpDeleteRequest.setHeader("Host","192.168.13.17");
    		httpDeleteRequest.setHeader("Authorization","Basic U2hhZmF0OlRlc3Q6NzE5QTRFQTUtQkY1OS00QkE3LUFBRDktNDc3N0Y4MkVFNTNFOjYzMTZBNDk2LUYzRUYtNEI5Qy1CQkQxLUI1MDQ1RDk2MTVDQjo=");
	    	Log.d("JSon","Get request");
		} 
    	catch (URISyntaxException e1) {
    		Log.d("JSon","Get request Error");
			e1.printStackTrace();
		}
    	
    	//Step 3:Execute the Request and Set Response Object
    	HttpResponse response = null;
    	try {
    		 Log.d("JSon","response start");
			 response = httpClient.execute(httpDeleteRequest);
			 Log.d("Response Status: ",String.valueOf(response.getStatusLine().getStatusCode()));
			 Log.d("JSon","response");

		} catch (ClientProtocolException e1) {
			Log.d("JSon","response Error in Protocol");
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			Log.d("JSon","response IOException");
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (Exception e){
			Log.d("JSON","General Response Exception : " + e.getMessage());
			e.printStackTrace();
		}
    	
    	if (response.getStatusLine().getStatusCode()==204)
    	    return 1;
    	else
    	    return -1;
	}

    //Method to post activity into a cloud
	public void PostActivityData()
	{         
	    try 
	    { 
	    	Log.d("POST","Called"); 
		     
	    	 //Step 1: Create JSON OBject Here
	    	 String  uniqueID = UUID.randomUUID().toString();
	    	 Log.d("Post ID:",uniqueID);
	    	 
		     JSONObject json = new JSONObject();
		     json.put("Activity_ID",uniqueID);
			 json.put("ActivityCode","POST :"  + String.valueOf(i));
			 json.put("ActivityDescription","RESTful POST Test ");
			 json.put("ActivityID","API01");
			 json.put("ActivitySub","API Check ");
			 Log.d("POST","1"); 
			 
			 i=i+1;
			 
			 //Step 2:Instantiate Client object
			 HttpClient client = new DefaultHttpClient();
			
			 //Step 3:Prepare HTTPPOST request
			 HttpPost postMethod = new HttpPost(url);
			 postMethod.addHeader("Content-Type", "application/json");
			 postMethod.addHeader("Accept", "application/json");
			 postMethod.addHeader("Authorization","Basic U2hhZmF0OlRlc3Q6NzE5QTRFQTUtQkY1OS00QkE3LUFBRDktNDc3N0Y4MkVFNTNFOjYzMTZBNDk2LUYzRUYtNEI5Qy1CQkQxLUI1MDQ1RDk2MTVDQjo=");
			 postMethod.setEntity(new StringEntity(json.toString(), HTTP.UTF_8));
	         Log.d("POST","2"); 
	         
	         //Step 4:Execute HTTPPOST request
	         HttpResponse response = client.execute(postMethod);
		     
	         // 200 type response.
	         if (response.getStatusLine().getStatusCode() >= HttpStatus.SC_OK &&
	         response.getStatusLine().getStatusCode() < HttpStatus.SC_MULTIPLE_CHOICES)
	         {
	               //Handle OK response etc
	               Log.d("HTTPPOST Request Executed","Successfully");	
	         }
		 } 
		 catch (Exception e) 
		 {
		     e.printStackTrace();
	     }
		 
	}
	
	//Method to put activity to a cloud
	public void PutActivityData()
	{
		 try 
		 {
			
			 
			//Step 1: Create JSON OBject Here 285a7f81-198c-4492-b511-3d78b97d5826
		    JSONObject json = new JSONObject();
	     	json.put("Activity_ID","2a6b6d72-b7cf-4557-899c-5ee63495e1d6");
    		json.put("ActivityCode","PUT :" + String.valueOf(i));
		    json.put("ActivityDescription","RESTfull PUT Test " + String.valueOf(i));
		    json.put("ActivitySub","JSON");
		    json.put("UpdateList","ActivitySub,ActivityCode,ActivityDescription");
		    //json.put("ActivityID","System Ins:");
		
		    i=i+1;
		    
		    //Step 2:Instantiate Client object
		    HttpClient client = new DefaultHttpClient();
		    
		    //Step 3:Prepare HTTPPUT request
 			HttpPut put= new HttpPut(url);
	        put.addHeader("Content-Type", "application/json");
            put.addHeader("Accept", "application/json");
            put.addHeader("Authorization","Basic U2hhZmF0OlRlc3Q6NzE5QTRFQTUtQkY1OS00QkE3LUFBRDktNDc3N0Y4MkVFNTNFOjYzMTZBNDk2LUYzRUYtNEI5Qy1CQkQxLUI1MDQ1RDk2MTVDQjo=");
            put.setEntity(new StringEntity(json.toString(), HTTP.UTF_8));
            
            //Step 4:Execute HTTPPUT request
            HttpResponse response = client.execute(put);
		    
            // 200 type response.
            if (response.getStatusLine().getStatusCode() >= HttpStatus.SC_OK &&
            response.getStatusLine().getStatusCode() < HttpStatus.SC_MULTIPLE_CHOICES)
            {
               //Handle OK response etc
               Log.d("HTTPPut Request Executed","Successfully");	
            }
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }
		
  }
}


	

